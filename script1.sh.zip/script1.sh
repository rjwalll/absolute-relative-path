#!/bin/bash
# Created for MCC INFO 1111 class
# by Jared Bernard
# This script will extract the CA.zip to the root directory

cd ~/Downloads
sudo unzip ~/Downloads/CA.zip -d /
sudo chown -R $USER:$USER /CA1
sudo chown -R $USER:$USER /CA2
cd /
ls

